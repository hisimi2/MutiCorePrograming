#include "stdafx.h"
#include "CAxisController.h"

CAxisController::CAxisController()
{

}
CAxisController::~CAxisController()
{

}

void CAxisController::MoveTo(double targetPosition)
{

}

double CAxisController::GetCurrentPosition()
{
	return 0.0;
}
